from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd

app = Flask(__name__)

# Load model
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.form
    features = pd.DataFrame({
        'openness': [data['openness']],
        'neuroticism': [data['neuroticism']],
        'conscientiousness': [data['conscientiousness']],
        'agreeableness': [data['agreeableness']],
        'extraversion': [data['extraversion']]
    })
    prediction = model.predict(features)
    return jsonify({'Personality': prediction[0]})

if __name__ == '__main__':
    app.run(debug=True)
