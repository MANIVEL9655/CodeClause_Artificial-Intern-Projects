from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import pickle
import pandas as pd

# Load the dataset
file_path = 'training_dataset.csv'
data = pd.read_csv(file_path)

# Define features and target
features = ['openness', 'neuroticism', 'conscientiousness', 'agreeableness', 'extraversion']
X = data[features]
y = data['Personality (Class label)']

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# Save the model
with open('model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)
